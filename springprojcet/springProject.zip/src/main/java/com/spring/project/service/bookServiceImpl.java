package com.spring.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.dao.BookDao;
import com.spring.project.model.AuthorVO;
import com.spring.project.model.BookVO;
import com.spring.project.model.Criteria;

@Service
public class bookServiceImpl implements bookService {

	@Autowired
	BookDao dao;
	
	//상품 총 갯수
	@Override
	public int booksGetTotal(Criteria cri) {
		return dao.booksGetTotal(cri);
	}

	/* 상품 검색 */
	@Override
	public List<BookVO> getBooksList(Criteria cri) {
		System.out.println("getGoodsList().......");

		String type = cri.getType();
		String[] typeArr = type.split("");
		List<BookVO> authorArr = dao.getAuthorIdList(cri.getKeyword(), cri.getAuthorArr());

		if(type.equals("A") || type.equals("AC") || type.equals("AT") || type.equals("ACT")) {
			if(authorArr.equals(null)) {
				return new ArrayList();
			}
		}
		for(String t : typeArr) {
			if(t.equals("A")) {
				cri.setAuthorArr(authorArr);
			}
		}		
		return dao.getBooksList(cri);
	}
	//작가 검색
	@Override
	public List<BookVO> getAuthorIdList(String keyword, List<BookVO> authorArr ) {
		return dao.getAuthorIdList(keyword, authorArr);
	}
}
