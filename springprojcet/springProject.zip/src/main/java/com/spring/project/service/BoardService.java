package com.spring.project.service;



import com.spring.project.model.BoardVO;



public interface BoardService {

	public int insert(BoardVO BoardVO);
	
	}

	

 