package com.spring.project.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.project.dao.BookDao;
import com.spring.project.model.AttachImageVO;
import com.spring.project.model.BookVO;
import com.spring.project.model.Criteria;
import com.spring.project.model.PageDTO;


@Controller
public class BookController {

	@Autowired
	BookDao dao;

	/* 이미지 정보 반환 */
	@GetMapping(value="/getAttachList", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<AttachImageVO>> getAttachList(int bookId){
		System.out.println("getAttachList 이미지 리스트 가져오기 북아이디"+bookId);
		return new ResponseEntity(dao.getAttachList(bookId),HttpStatus.OK);
	}
	@GetMapping("/display")
	public ResponseEntity<byte[]> getImage(String fileName){

		System.out.println("getImage() "+fileName);
		File file = new File("c:\\upload\\" + fileName);
		ResponseEntity<byte[]> result = null;
		try {
			HttpHeaders header = new HttpHeaders();
			header.add("Content-type", Files.probeContentType(file.toPath()));

			result = new ResponseEntity<>(FileCopyUtils.copyToByteArray(file), header, HttpStatus.OK);
		}catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	/* 상품 검색 */
	@RequestMapping(value="/search", method = RequestMethod.GET)
	public String searchGoodsGET(Criteria cri, Model model) {
		System.out.println("cri : " + cri);
		
		List<BookVO> list =dao.getBooksList(cri);
		if(!list.isEmpty()) {
			model.addAttribute("list", list);
		System.out.println("list : " + list);
		} else {
			model.addAttribute("listcheck", "empty");
			return "/search";
		}
		model.addAttribute("pageMaker", new PageDTO(cri, dao.booksGetTotal(cri)));
		return "/search";
		
	}
}