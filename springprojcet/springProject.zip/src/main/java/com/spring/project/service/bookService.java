package com.spring.project.service;

import java.util.List;
import java.util.Map;

import com.spring.project.model.AuthorVO;
import com.spring.project.model.BookVO;
import com.spring.project.model.Criteria;

public interface bookService {
	/* 상품 검색 */
	public List<BookVO> getBooksList(Criteria cri);
	
	/* 상품 총 갯수 */
	public int booksGetTotal(Criteria cri);
	
	/* 작가 id 리스트 요청 */
	public List<BookVO> getAuthorIdList(String keyword, List<BookVO> authorArr);

}
